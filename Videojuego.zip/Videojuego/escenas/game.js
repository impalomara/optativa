import { Scoreboard } from "../componentes/Scoreboard.js";

export class Game extends Phaser.Scene{
    constructor(){
        super({key: 'game'});
    }
    init(){
        this.scoreboard = new Scoreboard(this) 

    }

    preload(){
        this.load.image('background','imagenes/background.png');
        this.load.image('platform','imagenes/platform.png');
        this.load.image('ball', 'imagenes/ball.png');
        this.load.image('bluebrick', 'imagenes/brickblue.png');
        this.load.image('blackbrick', 'imagenes/brickBlack.png');
        this.load.image('greenbrick', 'imagenes/brickGreen.png');
        this.load.image('orangebrick', 'imagenes/brickOrange.png');
        this.load.image('congratulation', 'imagenes/congratulations.png');
    }
    create(){
        this.physics.world.setBoundsCollision(true, true, true, false);

        this.add.image(400,250,'background');

/*        
this.gameoverImage =this.add.image(400,90,'gameovers');
        this.gameoverImage.visible=false;
        
        this.gameoverImage =this.add.image(400,90,'congratulation');
       
        this.gameoverImage.visible=false;
*/ 
        this.scoreboard.create();

        this.bricks= this.physics.add.staticGroup({
            key:['bluebrick','blackbrick', 'greenbrick', 'orangebrick'],
            frameQuantity:10,
            gridAlign:{
                width:10,
                height:4,
                cellWidgth:67,
                cellHeight:34,
                x:112,
                y:100
            }
        })

        /*
        this.miGrupo = this.physics.add.staticGroup();
        this.miGrupo.create(254,244, 'bluebrick');
        this.miGrupo.create(375, 232, 'greenbrick');
*/
        this.scoreText = this.add.text(16,16, `Puntos: 0`,{
            fontSice:`20px`,
            fill:`#fff`,
            fontFamily:`verdana,arial,sans-serif`
        })
        this.platform = this.physics.add.image(400,460,'platform').setImmovable();
        this.platform.body.allowGravity = false;
        this.cursos = this.input.keyboard.createCursorKeys();

        this.ball = this.physics.add.image(385,430,'ball');
        this.ball.setData('glue', true);

        this.physics.add.collider(this.ball,this.platform);
        this.physics.add.collider(this.ball, this.miGrupo, this.platformImpact,null, this);

        this.physics.add.collider(this.ball, this.bricks, this.brickImpact,null, this);

        this.ball.setBounce(1);

        this.ball.setCollideWorldBounds(true);
        let velocity = 100 * Phaser.Math.FloatBetween(1.3, 2);
        if(Phaser.Math.Between(0,10) >5){
            velocity = 0 - velocity;
        }
        this.ball.setVelocity(velocity,10);

        this.cursos = this.input.keyboard.createCursorKeys();

        this.physics.add.collider(this.ball, this.platform, this.platformImpact, null, this);
    }

    platformImpact(ball, platform){
        this.scoreboard.incrementPoints(1);
        let relativeImpact = ball.x - platform.x;
        console.log(relative);

        if(relativeImpact < 0.1 && relativeImpact > -0.1){
            ball.setVelocityX(Phaser.Math.Between(-10,10))
        } else {
            ball.setVelocityX(10 * relativeImpact);
        }
    }

    ejecutar(){
        console.log("ha chocado");
        this.ball.setVelocity(10, -800);
    }

    brickImpact(ball, brick){
        brick.disableBody(true, true);
        this.scoreboard.incrementPoints(10);

        if(this.bricks.countActive===0){
            this.showCongratulations()
        }
    }

    update(){
        if (this.cursos.left.isDown){
            this.platform.setVelocityX(-500);
            if(this.ball.getData('glue')){
                this.ball.setVelocityX(-500);
            }
        } else  if (this.cursos.right.isDown){
            this.platform.setVelocityX(500);
                if(this.ball.getData('glue')){
                    this.ball.setVelocityX(500);
                }
        } else{
        this.platform.setVelocityX(0);
                if(this.ball.getData('glue')){
                    this.ball.setVelocityX(0);
                }
        }


        if(this.ball.y >500){
            this.showGameOver()
        }

        if(this.cursos.up.isDown){
            this.ball.setVelocity(-75,-300);
            this.ball.setData('glue',false);
        }
    }

    showGameOver(){
        this.scene.start('gameover');
    }

}