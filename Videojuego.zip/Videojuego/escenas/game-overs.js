import { RestartButton } from "../componentes/RestartButtons.js";

export class Gameovers extends Phaser.Scene{

     constructor(){
        super({key:'gameover'});
        this.restartButton = new RestartButton(this);
    }

    preload(){
        this.preload.image('gameover','images/gameover.png');
        this.restartButton.preload();
    }
    create(){
        this.add.image(410,250,'background');
        this.restartButton.create();
        this.GameoverImage = this.add.image(400, 90, 'gameover');
    }

}