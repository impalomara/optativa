import { Congratulations } from './escenas/congratulations.js';
import { Gameovers } from './escenas/game-overs.js';
import {Game} from './escenas/game.js'

const config ={
    type: Phaser.AUTO,
    width:800,
    height:500,
    scene:[Game, Congratulations, Gameovers],
    physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: 40},
            debug: false
        }
    }
}
var game = new Phaser.Game(config);