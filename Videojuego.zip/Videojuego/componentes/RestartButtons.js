export class RestartButton{
    constructor(scene){
        this.relatedScene = scene;
    }

    preload(){
        this.relatedScene.load.spritesheet('button', 'imagenes/restart.png', { frameWidth: 193, frameHeight: 71 });    }
    create(){
        this.startButton = this.relatedScene.add.sprite(400, 230, 'button').setInteractive();
        
        this.startButton.on('pointerover', () => {
            this.startButton.setFrame(1);
        });

        this.startButton.on('pointerout', () => {
            this.startButton.setFrame(0);
        });

        this.startButton.on('pointerdown', () => {
            console.log("pasa por aqui");
            this.relatedScene.scene.start('game');
        });
    };
}